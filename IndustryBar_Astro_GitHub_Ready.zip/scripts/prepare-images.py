"""Create derivative images for the local preview only, never overwrite Drive masters."""
from pathlib import Path
from PIL import Image, ImageOps, ImageDraw, ImageFont
from shutil import copyfile
import os

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'public'/'images'; OUT.mkdir(parents=True,exist_ok=True)
SRC=Path(os.environ.get('INDUSTRY_PHOTOS_SOURCE','/mnt/data'))
if not (SRC/'Industry Bar Employee Photos-5664.jpg').exists():
    raise SystemExit('Original Industry Bar photo files not found. Set INDUSTRY_PHOTOS_SOURCE to your photo folder. The optimized derivatives are already bundled in public/.')
PHOTOS={
 'pool-action':'5664','cocktail-coupe':'4281','cocktail-red':'4277',
 'cocktail-citrus':'4279','cocktail-copper':'4282','group-toast':'3841',
 'team-bar':'5506','darts-throw':'5042','darts-wide':'5271',
 'pool-friends':'5963','pool-detail':'5632','cheers-detail':'3821',
 'pool-together':'5881','bar-social':'5463',
}
for slug,number in PHOTOS.items():
 im=ImageOps.exif_transpose(Image.open(SRC/f'Industry Bar Employee Photos-{number}.jpg')).convert('RGB')
 for max_w in (640,1280,1920):
  if max_w>1280 and slug not in ('pool-action','cocktail-coupe','team-bar','group-toast','pool-friends'):
   continue
  res=im.copy();res.thumbnail((max_w,1600),Image.Resampling.LANCZOS)
  res.save(OUT/f'{slug}-{max_w}.webp',format='WEBP',quality=81 if max_w<1920 else 80,method=5)
 im.thumbnail((1280,1280),Image.Resampling.LANCZOS)
 im.save(OUT/f'{slug}.jpg',format='JPEG',quality=80,optimize=True,progressive=True,subsampling=0)

B=ROOT/'public'/'brand';B.mkdir(exist_ok=True)
for original,name in (
 ('Industry_Bar_Logo_Web_Optimized.svg','logo-stacked.svg'),
 ('Industry_Bar_Wordmark_Web.svg','logo-wordmark.svg'),
 ('Industry_Bar_Mascot_Mark_Web.svg','logo-mascot.svg')):
 copyfile(SRC/original,B/name)

mark=Image.open(SRC/'Industry_Bar_Mascot_Mark_Web.png').convert('RGBA')
mark.thumbnail((150,150),Image.Resampling.LANCZOS)
for px in (48,192):
 icon=Image.new('RGBA',(px,px),'#F2E5D7')
 tmp=mark.copy();tmp.thumbnail((int(px*.90),int(px*.90)),Image.Resampling.LANCZOS)
 icon.alpha_composite(tmp,((px-tmp.width)//2,(px-tmp.height)//2))
 icon.save(ROOT/'public'/'icons'/('favicon.png' if px==48 else 'apple-touch-icon.png'))

# Image for Open Graph: existing approved outlined logo, not substitute lettering.
og=Image.new('RGBA',(1200,630),'#F2E5D7')
right=Image.open(OUT/'pool-action-1280.webp').convert('RGB')
right=ImageOps.fit(right,(560,630),Image.Resampling.LANCZOS,centering=(0.56,0.5))
og.alpha_composite(right.convert('RGBA'),(640,0))
shade=Image.new('RGBA',(560,630),(11,23,46,40));og.alpha_composite(shade,(640,0))
d=ImageDraw.Draw(og); d.rectangle((635,0,646,630),fill='#CF7629')
word=Image.open(SRC/'Industry_Bar_Wordmark_Web.png').convert('RGBA')
word.thumbnail((490,225),Image.Resampling.LANCZOS)
og.alpha_composite(word,(75,155))
d=ImageDraw.Draw(og)
d.rectangle((75,405,235,411),fill='#CF7629')
try:
 regular=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',23)
 small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',19)
except OSError: regular=small=ImageFont.load_default()
d.text((75,439),'COCKTAILS  •  POOL  •  DARTS',fill='#0B172E',font=regular)
d.text((75,490),'101 SE 1ST ST  /  EVANSVILLE',fill='#485670',font=small)
og.convert('RGB').save(ROOT/'public'/'og.jpg',quality=86,optimize=True)
print('Prepared',len(PHOTOS),'photographs, brand SVGs, icons, and Open Graph art')
