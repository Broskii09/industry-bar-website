import test from 'node:test';
import assert from 'node:assert/strict';
import {parseCsv,mapMenu,mapEvents} from '../scripts/sync-sheets.mjs';

test('CSV handles quoted commas and quoted newlines',()=>{
  const rows=parseCsv('id,name,description\na,"Example, one","First line\nSecond line"\n');
  assert.equal(rows[0].name,'Example, one');
  assert.equal(rows[0].description,'First line\nSecond line');
});
test('only published menu items are included',()=>{
  const rows=parseCsv('id,name,category,ingredients,description,price,image,featured,published\na,Example,Seasonal,Citrus,Copy,$10,cocktail-red,yes,yes\nb,Draft,Seasonal,,,,,no,no\n');
  assert.equal(mapMenu(rows).length,1);
  assert.equal(mapMenu(rows)[0].featured,true);
});
test('reject unknown photo keys',()=>{
  const rows=parseCsv('id,name,category,image,published\na,Example,Seasonal,../../secrets,yes\n');
  assert.throws(()=>mapMenu(rows),/Unknown image slug/);
});
test('event dates must include timezone',()=>{
  const rows=parseCsv('slug,title,description,start_at,published\nshow,Show,Example,2026-11-20T19:00,yes\n');
  assert.throws(()=>mapEvents(rows),/timezone-qualified/);
});
test('published event is accepted with Central offset',()=>{
  const rows=parseCsv('slug,title,description,start_at,end_at,published\nshow,Show,Example,2026-11-20T19:00:00-06:00,2026-11-20T22:00:00-06:00,yes\n');
  assert.equal(mapEvents(rows)[0].slug,'show');
});
test('CSV parsed content is safe to render as plain text',()=>{
  const rows=parseCsv('id,name,category,image,published\na,"<img src=x onerror=alert(1)>",Seasonal,cocktail-red,yes\n');
  assert.equal(mapMenu(rows)[0].name,'<img src=x onerror=alert(1)>');
  // Astro escapes text substitutions; this verifies the importer does not treat fields as HTML.
});
