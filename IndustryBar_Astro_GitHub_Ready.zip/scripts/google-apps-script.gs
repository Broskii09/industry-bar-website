/**
 * OPTIONAL: install in the shared Google Sheet as an INSTALLABLE on-edit trigger.
 * Trigger dispatches a GitHub Actions site rebuild on spreadsheet edits.
 * Store GITHUB_OWNER, GITHUB_REPO, GITHUB_TOKEN in Script Properties.
 * Use a fine-grained token limited to the repo, with Contents: Read and write.
 * Never put the token in a public Sheet cell or client-side JavaScript.
 * Note: script/API-driven edits may not fire onEdit; use manual "Publish" if required.
 */
function industryBarOnEdit(e) {
  if (!e || !e.range) return;
  const sheetName=e.range.getSheet().getName();
  if (!['Cocktails','Events','Food'].includes(sheetName)) return;
  const lock=LockService.getScriptLock();
  if (!lock.tryLock(1000)) return;
  try {
    // Reset the one-shot timer for each edit so a partial editing session is not published.
    ScriptApp.getProjectTriggers()
      .filter(t=>t.getHandlerFunction()==='industryBarPublish')
      .forEach(t=>ScriptApp.deleteTrigger(t));
    ScriptApp.newTrigger('industryBarPublish').timeBased().after(60 * 1000).create();
  } finally { lock.releaseLock(); }
}

function industryBarPublish() {
  const props=PropertiesService.getScriptProperties();
  const owner=props.getProperty('GITHUB_OWNER');
  const repo=props.getProperty('GITHUB_REPO');
  const token=props.getProperty('GITHUB_TOKEN');
  if (!owner || !repo || !token) throw new Error('Configure GITHUB_OWNER, GITHUB_REPO, and GITHUB_TOKEN in Script Properties');
  const result=UrlFetchApp.fetch('https://api.github.com/repos/'+encodeURIComponent(owner)+'/'+encodeURIComponent(repo)+'/dispatches',{
    method:'post',contentType:'application/json',
    headers:{Authorization:'Bearer '+token,Accept:'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'},
    payload:JSON.stringify({event_type:'industry-bar-sheet-updated'}),muteHttpExceptions:true
  });
  if (result.getResponseCode()!==204) throw new Error('GitHub dispatch failed: HTTP '+result.getResponseCode());
}
