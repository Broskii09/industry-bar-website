/** Build-time Google Sheets CSV ingestion. Source is a published, read-only CSV for each tab. */
import fs from 'node:fs';
import path from 'node:path';

if (fs.existsSync('.env') && typeof process.loadEnvFile === 'function') process.loadEnvFile('.env');
const dir = path.resolve('src/data');
const production = process.env.SITE_MODE === 'production';
const menuFile = path.join(dir, 'menu.generated.json');
const eventsFile = path.join(dir, 'events.generated.json');
const foodFile = path.join(dir, 'food.generated.json');
const photos = new Set(['cocktail-coupe', 'cocktail-red', 'cocktail-citrus', 'cocktail-copper', 'pool-action', 'pool-friends', 'group-toast', 'team-bar']);
const required = (value, name, row) => {
  const v = String(value ?? '').trim();
  if (!v) throw new Error(`Missing ${name} in row ${row}`);
  return v;
};
const bool = v => ['true','yes','y','1','published'].includes(String(v ?? '').trim().toLowerCase());
const normalize = v => String(v ?? '').trim();

export function parseCsv(csv) {
  const rows = []; let field = '', row = [], inQuotes = false;
  csv = csv.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
  for (let i=0;i<csv.length;i++) {
    const char=csv[i];
    if (inQuotes) {
      if (char === '"' && csv[i+1] === '"') { field += '"'; i++; }
      else if (char === '"') inQuotes = false;
      else field += char;
    } else {
      if (char === '"') inQuotes=true;
      else if (char === ',') { row.push(field); field=''; }
      else if (char === '\n') { row.push(field); rows.push(row); row=[]; field=''; }
      else field += char;
    }
  }
  if (inQuotes) throw new Error('Unclosed quote in CSV');
  if (field || row.length) { row.push(field); rows.push(row); }
  const headers = (rows.shift() || []).map(x => x.trim().toLowerCase());
  if (!headers.length) throw new Error('CSV missing header row');
  if (new Set(headers).size !== headers.length) throw new Error('Duplicate CSV headers');
  return rows.filter(values => values.some(v=>v.trim())).map((values,idx) => {
    if (values.length !== headers.length) throw new Error(`CSV row ${idx+2} has ${values.length} fields; expected ${headers.length}`);
    return Object.fromEntries(headers.map((key, i)=>[key,values[i]]));
  });
}
export function mapMenu(rows) {
  const ids = new Set();
  return rows.filter(row => bool(row.published)).map((row,i) => {
    const id = required(row.id, 'id', i+2);
    if (ids.has(id)) throw new Error(`Duplicate menu id: ${id}`);
    ids.add(id);
    const image = normalize(row.image);
    if (image && !photos.has(image)) throw new Error(`Unknown image slug '${image}' for menu item ${id}`);
    return {id, name:required(row.name,'name',i+2), category:required(row.category,'category',i+2),
      ingredients:normalize(row.ingredients),description:normalize(row.description),price:normalize(row.price)||null,
      image:image || 'cocktail-coupe',featured:bool(row.featured), published:true};
  });
}
export function mapEvents(rows) {
  const slugs = new Set();
  return rows.filter(row => bool(row.published)).map((row,i) => {
    const slug = required(row.slug,'slug',i+2);
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) throw new Error(`Invalid event slug '${slug}'`);
    if (slugs.has(slug)) throw new Error(`Duplicate event slug: ${slug}`);
    slugs.add(slug);
    const start_at = required(row.start_at,'start_at',i+2);
    const end_at = normalize(row.end_at) || null;
    const iso=/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?(?:Z|[+-]\d{2}:\d{2})$/;
    if (!iso.test(start_at) || Number.isNaN(Date.parse(start_at))) throw new Error(`Invalid timezone-qualified start_at: ${slug}`);
    if (end_at && (!iso.test(end_at) || Number.isNaN(Date.parse(end_at)))) throw new Error(`Invalid timezone-qualified end_at: ${slug}`);
    if (end_at && Date.parse(end_at) < Date.parse(start_at)) throw new Error(`Event ends before start: ${slug}`);
    return {slug,title:required(row.title,'title',i+2),description:required(row.description,'description',i+2),start_at,end_at,published:true};
  });
}
async function pull(url,label) {
  const u = new URL(url);
  if (u.protocol !== 'https:' || u.hostname !== 'docs.google.com') throw new Error(`${label}: CSV URL must be an https://docs.google.com/... URL`);
  const response = await fetch(url,{signal:AbortSignal.timeout(20000)});
  if (!response.ok) throw new Error(`${label}: HTTP ${response.status}`);
  const text = await response.text();
  if (text.trim().startsWith('<')) throw new Error(`${label}: URL returned HTML (check sheet publishing/access)`);
  return parseCsv(text);
}
async function main() {
  const menuUrl=process.env.MENU_CSV_URL;
  const eventUrl=process.env.EVENTS_CSV_URL;
  const foodUrl=process.env.FOOD_CSV_URL;
  if (production && !menuUrl) throw new Error('SITE_MODE=production requires MENU_CSV_URL. Refusing to deploy demo menu.');
  if (!production && process.env.PUBLIC_ALLOW_INDEXING === 'true') throw new Error('Preview mode cannot enable search indexing. Set SITE_MODE=production and connect a real menu.');
  if (production && process.env.PUBLIC_ALLOW_INDEXING !== 'true') console.warn('Production mode has indexing disabled.');
  // Fetch and validate EVERYTHING before writing: failure keeps the last successful deployment.
  const prepared=[];
  if (menuUrl) {const items=mapMenu(await pull(menuUrl,'MENU_CSV_URL'));prepared.push([menuFile,{source:'google-sheets',generatedAt:new Date().toISOString(),items}]);}
  if (foodUrl) {
    const items= (await pull(foodUrl,'FOOD_CSV_URL')).filter(row=>bool(row.published)).map((row,i)=>({
      id:required(row.id,'id',i+2),name:required(row.name,'name',i+2),description:normalize(row.description),
      category:normalize(row.category),price:normalize(row.price)||null,published:true
    }));
    prepared.push([foodFile,{source:'google-sheets',generatedAt:new Date().toISOString(),items}]);
  } else prepared.push([foodFile,{source:'none',generatedAt:null,items:[]}]);
  if (eventUrl) {const items=mapEvents(await pull(eventUrl,'EVENTS_CSV_URL'));prepared.push([eventsFile,{source:'google-sheets',generatedAt:new Date().toISOString(),items}]);}
  else prepared.push([eventsFile,{source:'none',generatedAt:null,items:[]}]);
  for (const [file,value] of prepared) fs.writeFileSync(file,JSON.stringify(value,null,2)+'\n');
  if (!menuUrl) console.log('Using clearly labeled sample cocktail data for prototype only.');
  console.log('Sheet sync complete:',prepared.map(x=>path.basename(x[0])).join(', ')||'no remote sheets');
}
if (process.argv[1] && path.resolve(process.argv[1])===path.resolve(new URL(import.meta.url).pathname)) main().catch(err=>{ console.error(err.message);process.exitCode=1; });
