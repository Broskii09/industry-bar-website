from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
import base64, mimetypes

ROOT=Path(__file__).resolve().parents[1]
PRE=ROOT/'preview'
OUT=ROOT/'design-previews'
OUT.mkdir(exist_ok=True)

def data_uri(file):
  file=Path(file)
  mime=mimetypes.guess_type(file.name)[0] or 'application/octet-stream'
  return f'data:{mime};base64,{base64.b64encode(file.read_bytes()).decode()}'

def inline(relative):
  page=PRE/relative
  soup=BeautifulSoup(page.read_text(),'html.parser')
  for sheet in list(soup.select('link[rel=stylesheet]')):
    css=(page.parent/sheet.get('href')).resolve().read_text()
    tag=soup.new_tag('style');tag.string=css;sheet.replace_with(tag)
  for script in list(soup.select('script[src]')):
    text=(page.parent/script.get('src')).resolve().read_text()
    tag=soup.new_tag('script');tag.string='(()=>{\n'+text+'\n})();';script.replace_with(tag)
  for src in soup.find_all('source'):
    src.decompose() # force the same local JPEG fallback; source WebP decoding was checked separately
  for img in soup.find_all('img'):
    if not img.get('src'): continue
    path=(page.parent/img.get('src')).resolve()
    img['src']=data_uri(path)
  for button in soup.select('[data-gallery-src]'):
    path=(page.parent/button.get('data-gallery-src')).resolve()
    button['data-gallery-src']=data_uri(path)
  return str(soup)

def paint_all(page):
  page.evaluate("Array.from(document.images).forEach(i=>i.loading='eager')")
  page.evaluate("async () => await Promise.all(Array.from(document.images).map(i=>i.decode().catch(()=>null)))")
  for img in page.locator('img').all():
    if img.get_attribute('src'):
      img.scroll_into_view_if_needed(timeout=4000)
      page.wait_for_timeout(25)
  page.evaluate('window.scrollTo(0,0)')
  page.wait_for_timeout(180)

errors=[]
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  desk=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
  desk.on('pageerror',lambda error:errors.append(str(error)))
  desk.set_content(inline('index.html'),wait_until='load',timeout=20000)
  paint_all(desk)
  desk.screenshot(path=str(OUT/'home-desktop.png'))
  desk.screenshot(path=str(OUT/'home-desktop-full.png'),full_page=True)
  print('desktop h1',desk.locator('h1').inner_text().replace('\n',' / '))
  print('desktop width',desk.evaluate('document.documentElement.scrollWidth'),'overflow',desk.evaluate('document.documentElement.scrollWidth>window.innerWidth'))
  print('desktop images',desk.locator('img').count(),'broken images',desk.evaluate('Array.from(document.images).filter(i=>!i.complete||i.naturalWidth===0).length'))
  desk.set_content(inline('menu/index.html'),wait_until='load',timeout=20000)
  assert desk.locator('.menu-item:not([hidden])').count()==4
  desk.locator('#menu-search').fill('ginger')
  print('GINGER visible count',desk.locator('.menu-item:not([hidden])').count(),'text:',desk.locator('#menu-results-count').inner_text(),'errors:',errors)
  assert desk.locator('.menu-item:not([hidden])').count()==1
  assert '1 drink' in desk.locator('#menu-results-count').inner_text().lower()
  desk.locator('#menu-search').fill('no-such-cocktail')
  assert desk.locator('#menu-empty').is_visible()
  desk.locator('#menu-search').fill('')
  desk.locator('button[data-filter="Seasonal"]').click()
  assert desk.locator('.menu-item:not([hidden])').count()==1
  desk.screenshot(path=str(OUT/'menu-desktop.png'))
  print('desktop menu search, zero results, filtering PASS')
  desk.set_content(inline('gallery/index.html'),wait_until='load',timeout=20000)
  desk.locator('[data-gallery-src]').first.click()
  assert desk.locator('#gallery-dialog').is_visible()
  desk.keyboard.press('Escape')
  assert not desk.locator('#gallery-dialog').is_visible()
  print('gallery dialog open and Escape close PASS')
  desk.set_content(inline('visit/index.html'),wait_until='load',timeout=20000)
  desk.locator('#load-map').click()
  assert desk.locator('#map-frame iframe').count()==1
  print('map opt-in injection PASS (external map request not tested)')
  mobile=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
  mobile.on('pageerror',lambda error:errors.append(str(error)))
  mobile.set_content(inline('index.html'),wait_until='load',timeout=20000)
  paint_all(mobile)
  mobile.screenshot(path=str(OUT/'home-mobile.png'))
  mobile.screenshot(path=str(OUT/'home-mobile-full.png'),full_page=True)
  print('mobile width',mobile.evaluate('document.documentElement.scrollWidth'),'overflow',mobile.evaluate('document.documentElement.scrollWidth>window.innerWidth'))
  mobile.locator('#nav-toggle').click()
  assert mobile.locator('#mobile-nav').is_visible()
  assert mobile.locator('#nav-toggle').get_attribute('aria-expanded')=='true'
  mobile.keyboard.press('Escape')
  assert not mobile.locator('#mobile-nav').is_visible()
  print('mobile nav open/Escape close PASS')
  mobile.set_content(inline('menu/index.html'),wait_until='load',timeout=20000)
  mobile.screenshot(path=str(OUT/'menu-mobile.png'))
  print('mobile menu width',mobile.evaluate('document.documentElement.scrollWidth'),'overflow',mobile.evaluate('document.documentElement.scrollWidth>window.innerWidth'))
  print('JS exceptions:',errors)
  browser.close()
if errors: raise SystemExit(1)
print('Screenshots written to',OUT)
