# Industry Bar Website — v0.1 local prototype

**Status:** Initial source build. Not ready to publish as the business's official site. No GitHub repository or live hosting has been changed.

## What is implemented

- Astro static-first project (no React runtime), responsive multi-page editorial design.
- Pages: Home, Cocktails, Our Story, Gallery, Visit, plus generated event detail pages for published events.
- Photographs selected from your supplied December 2025 Industry Bar photo library, optimized to responsive WebP/JPEG sizes.
- Existing vector logo derivatives used as *temporary web assets*. Original AI/EPS sources are untouched; replace later with approved master exports.
- Brand-inspired Oxford Blue / Almond section system, with **provisional artwork-sampled ochre** pending confirmation of the exact master swatch.
- Vanilla TypeScript for accessible mobile navigation, instant menu search and category filters, gallery dialog, and opt-in map loading.
- Build-time Google Sheets CSV content for cocktails, events, and optional food; fail-closed validation.
- Event promotion appears on the homepage only when a published event is upcoming; published past event URLs remain available.
- HTML metadata, canonical URLs, social sharing image, BarOrPub JSON-LD, event JSON-LD, sitemap, and staging noindex by default.
- GitHub Actions Pages workflow for **TEST ONLY**; no live deployment.

## Run locally

Requires Node 20.11+ (Node 22 preferred) and internet access to install Astro once.

```bash
npm install
cp .env.example .env
npm run dev
```

Open http://localhost:4321. `npm run build` runs the Sheets importer then generates static files in `dist/`.

**Tooling limitation at handoff:** This environment could not reach the npm registry, so Astro dependencies could not be installed and the Astro compiler/build was **not executed here**. The standalone browser-style preview in `preview/` is generated without Astro, shares the design CSS and photo assets, and is provided for layout review. It is **not** a substitute for testing the Astro output after `npm install`. In-memory Chromium checks of this preview passed at 1440px desktop and 390px mobile, including search/filter, gallery, nav, and map opt-in interactions. The screenshot exports are in `design-previews/`.

To inspect the static preview without dependencies, open `preview/index.html` in a browser, or run:

```bash
python -m http.server 8000 --directory preview
```

Then visit http://localhost:8000. The `preview/` folder is temporary; edit the canonical `src/` files for lasting changes.

## Content: Google Sheets integration

There is no spreadsheet connected yet. Until you add a real sheet, all menu entries carry **design preview / sample** wording; event and food datasets are empty. These are NOT verified current cocktails, prices, hours, or events.

Suggested setup:

1. Make a Google Sheet owned by Industry Bar, and share editing permission with the owner and website administrator only.
2. Create three tabs with the exact names `Cocktails`, `Events`, and optionally `Food`. Start from the header rows in `templates/`.
3. Publish the relevant *individual tabs* as read-only CSV links (Google Sheets: File > Share > Publish to web, or a suitably public CSV export). **These published rows are public; don't include private information.**
4. In `.env` (local) or GitHub repository Secrets (TEST), set `MENU_CSV_URL`, `EVENTS_CSV_URL`, and optional `FOOD_CSV_URL`.
5. Run `npm run build`. `scripts/sync-sheets.mjs` validates all published entries before writing new JSON; if invalid, the build exits with an error rather than silently publishing broken content.
6. For automatic rebuilds after owner edits, install the template in `scripts/google-apps-script.gs` as a bound Apps Script. Add an **installable on-edit trigger** pointing to `industryBarOnEdit`. Set `GITHUB_OWNER`, `GITHUB_REPO`, and `GITHUB_TOKEN` in Apps Script Properties (not sheet cells). It schedules a delayed GitHub `repository_dispatch` so multiple cell edits coalesce into one build. The workflow is in `.github/workflows/pages.yml`.

**Timing:** Edits should normally appear within a few minutes after the editing session, but the actual latency depends on Apps Script trigger scheduling, GitHub build queues, and deployment. It is not guaranteed real-time. For non-human changes made via scripts/API, use manual publish or an alternate trigger because Google edit triggers may not fire.

### Cocktail columns

`id,name,category,ingredients,description,price,image,featured,published`

- `published`: TRUE/FALSE. Unpublished rows never appear.
- `featured`: TRUE/FALSE. Featured published drinks appear on the homepage.
- `price`: Optional plain text, do not fabricate prices.
- `image`: One of `cocktail-coupe`, `cocktail-red`, `cocktail-citrus`, `cocktail-copper`. New images require updating the source media library and allowlist. The initial cocktail photos are from a previous shoot; verify accuracy with the owner before publishing real menu entries.
- `id`: Stable unique identifier, even if the drink's name changes.

### Event columns

`slug,title,description,start_at,end_at,published`

- Use timezone-qualified ISO 8601 (e.g. `2026-11-20T19:00:00-06:00`; Evansville is America/Chicago). Daylight saving changes offset by season; do not hard-code `-06:00` year-round.
- Published events receive `/events/slug/` pages. The homepage only shows those whose end time has not passed at **build time**. Client-side code hides expired event promotions between deployments, and a later build updates the static homepage/sitemap. For accurate HTML on expiration and timed indexing, add scheduled rebuilds.
- `end_at` is optional, but strongly recommended.

### Optional food columns

`id,name,category,description,price,published`

No food section is displayed while there are no published entries. When a confirmed food list exists, connect `FOOD_CSV_URL`.

## Github Pages TEST

- Create a new repository and push these files to `main` **after the local build succeeds**.
- GitHub Settings > Pages > Source: GitHub Actions.
- The included workflow configures `SITE_URL=https://OWNER.github.io` and `BASE_PATH=/REPOSITORY/` for project pages, or `/` if the repo is `OWNER.github.io`.
- TEST builds force `PUBLIC_ALLOW_INDEXING=false` and generate `robots.txt` disallowing indexing.
- The workflow currently runs `npm install` because a dependency lockfile could not be generated offline. After your first successful local install, commit `package-lock.json` and switch the workflow to `npm ci` for reproducibility.
- GitHub Pages is the **TEST** host only; select an appropriate commercial host such as Cloudflare Pages for production after approvals and testing.

## Production safeguards and outstanding confirmations

- Use `SITE_MODE=production` to prevent a production build with sample menu data; `MENU_CSV_URL` becomes mandatory. A preview build is also blocked from enabling search indexing. Set `PUBLIC_ALLOW_INDEXING=true` only after the official domain/URL and all business details are verified.
- Confirm owner approval and model releases/publication permissions for identifiable people.
- Confirm exact logo colors, web-font licenses, and supply approved native AI-based variants. Do not copy/download commercial font files into this project without permission.
- Confirm the current drink names, ingredients, prices, and which photos actually match them.
- Confirm business hours, phone, parking, Instagram handle, full brand story, and official domain. Unconfirmed items remain omitted or explicitly labeled.
- Before production: Astro build, visual browser checks, Lighthouse/axe, route smoke tests, schema validation, mobile navigation, content edit-to-publish timing, and HTTPS/canonical checks.

## Source-of-truth and preservation

The first version uses the files supplied in this conversation as the only artwork/photo inputs. EPS and `Package.ai` remain reference-only; no Illustrator files were edited. The new website did not exist in the current build context, so nothing was overwritten. Future patches should be surgical and preserve existing functionality unless specifically approved.

**Environment:** Local v0.1 only; GitHub TEST is configured but not deployed; root/live is not touched.

## Critical feature regression check

- **Verified unchanged:** Source AI/EPS and all photos; no Drive or GitHub writes.
- **Affected intentionally:** New local Astro project, content schema and optimized derivatives.
- **Not verified:** Astro compiler/build, hosted/browser interactions, real Google Sheets publishing, and production SEO/indexing.

### Photo optimization source

Processed site images are already bundled. To regenerate them later from the original photos, point `INDUSTRY_PHOTOS_SOURCE` to the folder containing original `Industry Bar Employee Photos-NNNN.jpg` filenames, then run `python scripts/prepare-images.py`. This script never modifies the originals.
