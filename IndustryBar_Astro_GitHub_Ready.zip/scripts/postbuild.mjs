import fs from 'node:fs';
import path from 'node:path';

if (fs.existsSync('.env') && typeof process.loadEnvFile === 'function') process.loadEnvFile('.env');
const root=path.resolve('dist');
const allow=process.env.PUBLIC_ALLOW_INDEXING==='true';
const base=(process.env.BASE_PATH||'/').replace(/^\/*/,'/').replace(/\/*$/,'/');
const site=(process.env.SITE_URL||'http://localhost:4321').replace(/\/$/,'');
if (!fs.existsSync(root)) throw new Error('Missing dist/ directory; run Astro build first');
const htmlFiles=[];
function walk(dir){for(const file of fs.readdirSync(dir,{withFileTypes:true})) {
 const full=path.join(dir,file.name);
 if(file.isDirectory())walk(full);else if(file.name==='index.html')htmlFiles.push(full);
}}
walk(root);
const urls=htmlFiles.map(f=>{
 let dir=path.dirname(path.relative(root,f)).replaceAll('\\','/');
 return new URL(base + (dir ? dir + '/' : ''),site).href;
}).sort();
const esc=v=>v.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
fs.writeFileSync(path.join(root,'sitemap.xml'),'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+urls.map(x=>'  <url><loc>'+esc(x)+'</loc></url>').join('\n')+'\n</urlset>\n');
fs.writeFileSync(path.join(root,'robots.txt'),allow?`User-agent: *\nAllow: /\nSitemap: ${new URL(base+'sitemap.xml',site).href}\n`:'User-agent: *\nDisallow: /\n');
fs.writeFileSync(path.join(root,'.nojekyll'),'');
console.log(`Wrote sitemap (${urls.length} pages) and ${allow?'indexable':'noindex'} robots.txt`);
