"""Independent consistency verification for the dependency-free static design preview."""
from pathlib import Path
from bs4 import BeautifulSoup
from urllib.parse import urlparse,unquote
from collections import Counter
R=Path(__file__).resolve().parents[1]
P=R/'preview'
errors=[]
count=0
pages=sorted(P.rglob('index.html'))
for page in pages:
 count+=1
 soup=BeautifulSoup(page.read_text(), 'html.parser')
 assert soup.select_one('main#main'),page
 assert soup.select_one('header.site-header'),page
 assert soup.select_one('footer.site-footer'),page
 for img in soup.select('img'):
  if img.get('alt') is None: errors.append(f'{page.relative_to(P)}: missing alt attribute')
 for el in soup.select('img[src],script[src],link[href],a[href]'):
  val=el.get('src') or el.get('href') or ''
  if val.startswith(('#','http://','https://','mailto:','tel:','data:')): continue
  dest=(page.parent/unquote(urlparse(val).path)).resolve()
  if val.endswith('/'):
   dest=dest/'index.html'
  if not dest.exists(): errors.append(f'{page.relative_to(P)}: missing {val}')
 for img in soup.select('source[srcset]'):
  for term in img.get('srcset').split(','):
   src=term.strip().split(' ')[0]
   if not (page.parent/src).resolve().exists(): errors.append(f'{page.relative_to(P)}: missing {src}')
css=(R/'src/styles/global.css').read_text()
if css.count('{') != css.count('}'): errors.append('CSS braces unbalanced')
if errors:
 print('\n'.join(errors));raise SystemExit(1)
print(f'Static preview passed: {count} pages, local image/script/style/link targets, alt attributes, CSS braces')
