# Build Status — Industry Bar v0.1

## Changes made
- New Astro source site and independent, dependency-free static preview.
- New optimized WebP/JPEG photo derivatives from previously supplied photos.
- Uses already-derived reference logo SVGs (not a polished master).
- Added Google Sheets importer, optional food, event route generation, and deferred owner-edit publishing example.
- Added accessibility, staging SEO and metadata safeguards.

## Target
- Local build. GitHub Pages TEST workflow supplied, **not deployed**.
- No live/root site or existing repository modified.

## Validation completed
- Six Node CSV parser/content tests pass.
- Static preview HTML links, images, and CSS validated.
- In-memory Chromium render: desktop (1440 px) and mobile (390 px) without horizontal overflow.
- In-memory Chromium interactions: menu search/category filtering, no-results state, modal gallery open/close, mobile nav toggle/Escape, opt-in map iframe injection.
- Image files generated with valid normalized formats; optimized public assets total ~5.7 MiB.
- Sitemap/robots postbuild generator smoke test passed on fixture pages.

## Validation blocked / pending
- Astro install/build blocked by unavailable npm registry in this environment.
- Direct Chromium local/HTTP navigation was restricted by runtime policy; in-memory page tests passed, but a full hosted URL QA pass remains necessary.
- Must run npm install / npm run build and local browser QA before TEST deployment.
- Live owner content, hours, parking, menu, social handles, and identifiable-photo release approvals pending.

## Critical feature regression check
- Verified unchanged: supplied originals and existing brand decisions.
- Affected intentionally: new local prototype only.
- Not verified: full browser/hosted regression and spreadsheet edit-to-deploy timing.
