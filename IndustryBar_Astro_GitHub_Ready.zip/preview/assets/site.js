const navButton = document.querySelector('#nav-toggle');
const nav = document.querySelector('#mobile-nav');
function closeNav() {
  if (!navButton || !nav) return;
  navButton.setAttribute('aria-expanded', 'false');
  navButton.setAttribute('aria-label', 'Open menu');
  nav.hidden = true;
  document.body.classList.remove('nav-open');
}
navButton?.addEventListener('click', () => {
  if (!nav) return;
  const open = navButton.getAttribute('aria-expanded') !== 'true';
  navButton.setAttribute('aria-expanded', String(open));
  navButton.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  nav.hidden = !open;
  document.body.classList.toggle('nav-open', open);
});
nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', closeNav));
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeNav(); });
window.addEventListener('resize', () => { if (window.innerWidth > 820) closeNav(); });

const search = document.querySelector('#menu-search');
const categories = document.querySelector('#menu-filters');
const cards = [...document.querySelectorAll('.menu-item')];
const resultCount = document.querySelector('#menu-results-count');
const emptyState = document.querySelector('#menu-empty');
let filter = 'all';
function refreshMenu() {
  const q = (search?.value || '').toLocaleLowerCase().trim();
  let shown = 0;
  for (const card of cards) {
    const matchCategory = filter === 'all' || card.dataset.category === filter;
    const matchText = (card.dataset.search || '').toLocaleLowerCase().includes(q);
    const visible = matchCategory && matchText;
    card.hidden = !visible;
    if (visible) shown++;
  }
  if (resultCount) resultCount.textContent = `${shown} ${shown === 1 ? 'drink' : 'drinks'} shown`;
  if (emptyState) emptyState.hidden = shown > 0 || cards.length === 0;
}
search?.addEventListener('input', refreshMenu);
categories?.addEventListener('click', event => {
  const target = event.target;
  const button = target.closest('button[data-filter]');
  if (!button) return;
  filter = button.dataset.filter || 'all';
  categories.querySelectorAll('button[data-filter]').forEach(b => b.setAttribute('aria-pressed', String(b === button)));
  refreshMenu();
});
refreshMenu();

const modal = document.querySelector('#gallery-dialog');
const modalImage = modal?.querySelector('img');
const modalCaption = modal?.querySelector('[data-dialog-caption]');
document.querySelectorAll('[data-gallery-src]').forEach(button => {
  button.addEventListener('click', () => {
    if (!modal || !modalImage || !modalCaption) return;
    const src = button.dataset.gallerySrc;
    if (!src) return;
    modalImage.src = src;
    modalImage.alt = button.dataset.galleryAlt || '';
    modalCaption.textContent = button.dataset.galleryAlt || '';
    modal.showModal();
  });
});
modal?.querySelector('[data-dialog-close]')?.addEventListener('click', () => modal.close());
modal?.addEventListener('click', event => { if (event.target === modal) modal.close(); });

const mapButton = document.querySelector('#load-map');
mapButton?.addEventListener('click', () => {
  const url = mapButton.dataset.mapSrc;
  const frameBox = document.querySelector('#map-frame');
  if (!url || !frameBox) return;
  const frame = document.createElement('iframe');
  frame.title = 'Map showing Industry Bar in downtown Evansville';
  frame.loading = 'lazy';
  frame.referrerPolicy = 'no-referrer-when-downgrade';
  frame.src = url;
  frame.setAttribute('allowfullscreen','');
  frameBox.replaceChildren(frame);
  mapButton.remove();
});

// Prevent a just-expired event from lingering between successful static rebuilds.
const eventSection = document.querySelector('#upcoming-events');
if (eventSection) {
  const now = Date.now();
  eventSection.querySelectorAll('[data-event-end]').forEach(item => {
    const end = Date.parse(item.dataset.eventEnd || '');
    if (!Number.isNaN(end) && end < now) item.hidden = true;
  });
  if (!eventSection.querySelector('[data-event-end]:not([hidden])')) eventSection.hidden = true;
}
