# Industry Bar — GitHub repository setup

Target: a dedicated repository named `industry-bar-website`, independent of other websites.

1. Create a new **empty** GitHub repository under `Broskii09` named `industry-bar-website`. Do not add an initial README, gitignore, or license.
2. Extract this ZIP. From inside the extracted directory, run:

```sh
git init -b main
git add .
git commit -m "Initial Industry Bar website v0.1"
git remote add origin https://github.com/Broskii09/industry-bar-website.git
git push -u origin main
```

3. Go to repository Settings → Pages. Choose **GitHub Actions** as the deployment source. The included `.github/workflows/pages.yml` builds the site using Astro.
4. Watch Actions for build success. Expected testing URL: `https://broskii09.github.io/industry-bar-website/` *after* deployment succeeds.
5. Menus are demonstration data until owner-approved Google Sheets sources are connected. Do not promote this TEST deployment as an official site.

Production remains separate from GitHub Pages. Google Sheets credentials or publishing webhook secrets must not be committed.

Note: The v0.1 source was not fully compiled in the original environment; test the Astro build in Actions and address any build failures before sharing.
